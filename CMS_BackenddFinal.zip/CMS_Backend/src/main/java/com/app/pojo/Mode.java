package com.app.pojo;



public enum Mode {
AIR,ROAD
}
